from flask import Flask,render_template
import requests

response= requests.get("https://api.npoint.io/c790b4d5cab58020d391").json()
app= Flask(__name__)

@app.route("/")
def guess():
    return render_template("index.html",data=response[0]["title"])

if __name__=="__main__":
    app.run(debug=True)
